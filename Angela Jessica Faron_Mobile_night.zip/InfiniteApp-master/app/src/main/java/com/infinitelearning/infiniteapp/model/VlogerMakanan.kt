package com.infinitelearning.infiniteapp.model

data class VlogerMakanan(
    val id: Int,
    val name: String,
    val photo: Int,
    val batch: String,
    val bumbu: String,
)