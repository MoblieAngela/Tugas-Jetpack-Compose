package com.infinitelearning.infiniteapp.model

data class Favorit(
    val id: Int,
    val name: String,
    val photo: Int,
)
