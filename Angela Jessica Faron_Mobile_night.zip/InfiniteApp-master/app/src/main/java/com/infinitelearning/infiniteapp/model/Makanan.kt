package com.infinitelearning.infiniteapp.model

data class Makanan(
    val id: Int,
    val name: String,
    val nickname: String,
    val saos: String,
    val photo: Int,
)
